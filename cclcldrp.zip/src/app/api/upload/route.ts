import { NextRequest, NextResponse } from "next/server";
import { writeFile } from "fs/promises";
import { join } from "path";
import { existsSync, mkdirSync } from "fs";

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const file = formData.get("file") as File | null;

    if (!file) {
      return NextResponse.json(
        { error: "No file received." },
        { status: 400 }
      );
    }

    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);

    // Save the file
    const uploadDir = join(process.cwd(), "uploads");
    
    // Ensure the uploads directory exists
    if (!existsSync(uploadDir)) {
      mkdirSync(uploadDir, { recursive: true });
    }

    // Save with the original filename (ensure safe filename in production)
    const filepath = join(uploadDir, file.name);
    await writeFile(filepath, buffer);

    console.log(`Saved file to ${filepath}`);

    return NextResponse.json({ success: true, message: "File uploaded." });
  } catch (error) {
    console.error("Upload error:", error);
    return NextResponse.json(
      { error: "Something went wrong during upload." },
      { status: 500 }
    );
  }
}
