import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // @ts-ignore - Next.js types might not be perfectly up to date for this new key
  allowedDevOrigins: ['192.168.29.240'],
};

export default nextConfig;
